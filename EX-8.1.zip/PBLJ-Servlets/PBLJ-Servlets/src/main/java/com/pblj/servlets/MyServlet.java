package com.pblj.servlets;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.http.*;

public class MyServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        response.setContentType("text/html");
        if ("admin".equals(username) && "admin123".equals(password)) {
            response.getWriter().println("<h1>Welcome, " + username + "!</h1>");
        } else {
            response.getWriter().println("<h1>Login failed. Please try again.</h1>");
        }
    }
}
