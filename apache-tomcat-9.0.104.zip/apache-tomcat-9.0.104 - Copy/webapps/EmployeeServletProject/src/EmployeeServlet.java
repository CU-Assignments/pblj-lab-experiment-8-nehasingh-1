
// EmployeeServlet.java
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/EmployeeServlet")
public class EmployeeServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String searchId = request.getParameter("emp_id");
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try (Connection conn = DBConnection.getConnection()) {
            if (searchId == null || searchId.isEmpty()) {
                String query = "SELECT * FROM employees";
                PreparedStatement stmt = conn.prepareStatement(query);
                ResultSet rs = stmt.executeQuery();

                out.println("<h1>Employee List</h1>");
                out.println("<table border='1'><tr><th>ID</th><th>Name</th><th>Position</th><th>Salary</th></tr>");

                while (rs.next()) {
                    out.println("<tr><td>" + rs.getInt("emp_id") + "</td><td>" + rs.getString("emp_name") + "</td><td>"
                            + rs.getString("emp_position") + "</td><td>" + rs.getDouble("emp_salary") + "</td></tr>");
                }

                out.println("</table>");
            } else {
                String query = "SELECT * FROM employees WHERE emp_id = ?";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setInt(1, Integer.parseInt(searchId));
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    out.println("<h1>Employee Details</h1>");
                    out.println("<table border='1'><tr><th>ID</th><th>Name</th><th>Position</th><th>Salary</th></tr>");
                    out.println("<tr><td>" + rs.getInt("emp_id") + "</td><td>" + rs.getString("emp_name") + "</td><td>"
                            + rs.getString("emp_position") + "</td><td>" + rs.getDouble("emp_salary") + "</td></tr>");
                    out.println("</table>");
                } else {
                    out.println("<h3>No employee found with ID: " + searchId + "</h3>");
                }
            }
        } catch (SQLException e) {
            out.println("<h3>Error: " + e.getMessage() + "</h3>");
        }
    }
}
